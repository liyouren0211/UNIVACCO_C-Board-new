// Native C# font alignment. Combined from the three original C# modules.
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System;

// ===== GoldenCharacters.cs =====
namespace StandardOPage
{
    // Reads exactly the BMP/CSV Golden Sample format supplied by the user; no legacy template scaling.
    public static class GoldenCharacters
    {
        public sealed class Glyph
        {
            public string Side, File;
            public int FontPt, Index, SourceWidth, SourceHeight, X0, Y0, X1, Y1;
        }
        private static readonly CultureInfo CI = CultureInfo.InvariantCulture;
        private static List<string> CsvFields(string line)
        {
            var result = new List<string>(); var s = new System.Text.StringBuilder(); bool quoted = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"') { if (quoted && i + 1 < line.Length && line[i + 1] == '"') { s.Append('"'); i++; } else quoted = !quoted; }
                else if (c == ',' && !quoted) { result.Add(s.ToString()); s.Clear(); }
                else s.Append(c);
            }
            result.Add(s.ToString()); return result;
        }
        public static List<Glyph> ReadCsv(string directory)
        {
            string[] lines = File.ReadAllLines(Path.Combine(directory, "character_coordinates.csv"), System.Text.Encoding.UTF8);
            if (lines.Length < 2) throw new InvalidDataException("Golden Sample CSV is empty");
            string[] headers = CsvFields(lines[0].TrimStart('\ufeff')).ToArray();
            var rows = new List<Glyph>();
            for (int line = 1; line < lines.Length; line++)
            {
                if (String.IsNullOrWhiteSpace(lines[line])) continue;
                var data = CsvFields(lines[line]);
                Func<string, string> get = key => { int k = Array.IndexOf(headers, key); if (k < 0 || k >= data.Count) throw new InvalidDataException("Missing CSV column: " + key); return data[k]; };
                Func<string, int> integer = key => int.Parse(get(key), CI);
                rows.Add(new Glyph
                {
                    Side = get("side"),
                    File = get("file"),
                    FontPt = integer("font_pt"),
                    Index = integer("index_top_to_bottom"),
                    SourceWidth = integer("source_width"),
                    SourceHeight = integer("source_height"),
                    X0 = integer("x0"),
                    Y0 = integer("y0"),
                    X1 = integer("x1"),
                    Y1 = integer("y1")
                });
            }
            return rows;
        }
        public static (byte[,] reference, Dictionary<int, int> xoffsets, List<Glyph> glyphs) Load(string directory, string side)
        {
            var rows = ReadCsv(directory).Where(r => r.Side == side).ToList();
            var fonts = new List<byte[,]>(); var offsets = new Dictionary<int, int>(); int totalWidth = 0, height = -1;
            for (int pt = 3; pt <= 12; pt++)
            {
                var rr = rows.Where(r => r.FontPt == pt).ToList();
                if (rr.Count == 0) throw new InvalidDataException(side + " " + pt + "pt missing");
                if (rr.Any(r => r.SourceWidth != rr[0].SourceWidth || r.SourceHeight != rr[0].SourceHeight))
                    throw new InvalidDataException("Inconsistent source dimensions");
                int w = rr[0].SourceWidth, h = rr[0].SourceHeight;
                if (height >= 0 && h != height) throw new InvalidDataException("Inconsistent font strip heights");
                height = h; byte bg = side == "Yin" ? (byte)0 : (byte)255;
                var canvas = new byte[h, w];
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) canvas[y, x] = bg;
                foreach (var r in rr)
                {
                    string fn = Path.Combine(directory, r.File.Replace('/', Path.DirectorySeparatorChar));
                    if (!File.Exists(fn)) throw new FileNotFoundException("Golden BMP missing", fn);
                    using (Mat bmp = CvInvoke.Imread(fn, ImreadModes.Grayscale))
                    {
                        byte[,] pixels = CharacterBandMatcher.ReadGray(bmp);
                        if (r.X0 < 0 || r.Y0 < 0 || r.X1 > w || r.Y1 > h || pixels.GetLength(1) != r.X1 - r.X0 || pixels.GetLength(0) != r.Y1 - r.Y0)
                            throw new InvalidDataException("Glyph mismatch: " + fn);
                        for (int y = 0; y < pixels.GetLength(0); y++) for (int x = 0; x < pixels.GetLength(1); x++) canvas[r.Y0 + y, r.X0 + x] = pixels[y, x];
                    }
                }
                offsets[pt] = totalWidth; totalWidth += w; fonts.Add(canvas);
            }
            if (totalWidth != 3550 && totalWidth != 3600) throw new InvalidDataException("Unsupported Golden width " + totalWidth);
            byte[,] reference = new byte[height, totalWidth];
            int offset = 0; foreach (var font in fonts)
            {
                int fw = font.GetLength(1);
                for (int y = 0; y < height; y++) for (int x = 0; x < fw; x++) reference[y, offset + x] = font[y, x];
                offset += fw;
            }
            return (reference, offsets, rows);
        }
        public static byte[,] Binary(byte[,] gray, bool isYin, int threshold = 150)
        {
            int h = gray.GetLength(0), w = gray.GetLength(1); var result = new byte[h, w];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++)
                    result[y, x] = (gray[y, x] > threshold) == isYin ? (byte)255 : (byte)0;
            return result;
        }
    }
}

// ===== CharacterBandMatcher.cs =====
// Native C# translation of the Python band_match scoring/search/acceptance logic.
// No Python process, runtime, script or bridge is used.
// Target: .NET Framework 4.7.2 + existing Emgu.CV project.
namespace StandardOPage
{
    public static class CharacterBandMatcher
    {
        public sealed class Match
        {
            public int BestDx, BestDy, UsedDx, UsedDy, SearchRadiusUsed;
            public bool Accepted;
            public double Before, Score;
            public string Reason;
            public Rectangle GoldenRoi;
            public byte[,] Golden, Original, Best, Used;
        }
        private sealed class Candidate
        {
            public int Dx, Dy;
            public double Score, Penalized;
        }
        public static byte[,] ReadGray(Mat mat)
        {
            using (var im = mat.ToImage<Gray, byte>())
            {
                byte[,] a = new byte[im.Height, im.Width];
                for (int y = 0; y < im.Height; y++) for (int x = 0; x < im.Width; x++) a[y, x] = im.Data[y, x, 0];
                return a;
            }
        }
        public static Mat WriteGray(byte[,] pixels)
        {
            int h = pixels.GetLength(0), w = pixels.GetLength(1);
            using (var im = new Image<Gray, byte>(w, h))
            {
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) im.Data[y, x, 0] = pixels[y, x];
                return im.Mat.Clone();
            }
        }
        public static byte[,] Slice(byte[,] src, int x, int y, int w, int h)
        {
            byte[,] dst = new byte[h, w]; int sh = src.GetLength(0), sw = src.GetLength(1);
            for (int j = 0; j < h; j++) if (y + j >= 0 && y + j < sh)
                    for (int i = 0; i < w; i++) if (x + i >= 0 && x + i < sw) dst[j, i] = src[y + j, x + i];
            return dst;
        }
        // 8-connected components smaller than four pixels are removed, as in Python skeleton().
        private static bool[,] Skeleton(byte[,] src)
        {
            int h = src.GetLength(0), w = src.GetLength(1);
            bool[,] a = new bool[h, w], visited = new bool[h, w];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) a[y, x] = src[y, x] > 0;
            int[] xx = { -1, 0, 1, -1, 1, -1, 0, 1 }, yy = { -1, -1, -1, 0, 0, 1, 1, 1 };
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (a[y, x] && !visited[y, x])
                    {
                        var q = new Queue<Point>(); var component = new List<Point>(); q.Enqueue(new Point(x, y)); visited[y, x] = true;
                        while (q.Count > 0)
                        {
                            Point p = q.Dequeue(); component.Add(p);
                            for (int k = 0; k < 8; k++)
                            {
                                int nx = p.X + xx[k], ny = p.Y + yy[k];
                                if (nx >= 0 && nx < w && ny >= 0 && ny < h && a[ny, nx] && !visited[ny, nx])
                                { visited[ny, nx] = true; q.Enqueue(new Point(nx, ny)); }
                            }
                        }
                        if (component.Count < 4) foreach (Point p in component) a[p.Y, p.X] = false;
                    }
            // Zhang-Suen two-subiteration thinning, the same algorithm family as skimage's 2D skeletonize.
            // Pixel-level equivalence requires regression verification on the provided real images.
            bool changed;
            do
            {
                changed = false;
                for (int pass = 0; pass < 2; pass++)
                {
                    var remove = new List<Point>();
                    for (int y = 1; y < h - 1; y++) for (int x = 1; x < w - 1; x++) if (a[y, x])
                            {
                                bool p2 = a[y - 1, x], p3 = a[y - 1, x + 1], p4 = a[y, x + 1], p5 = a[y + 1, x + 1],
                                     p6 = a[y + 1, x], p7 = a[y + 1, x - 1], p8 = a[y, x - 1], p9 = a[y - 1, x - 1];
                                bool[] v = { p2, p3, p4, p5, p6, p7, p8, p9 }; int n = v.Count(z => z), trans = 0;
                                for (int k = 0; k < 8; k++) if (!v[k] && v[(k + 1) % 8]) trans++;
                                if (n < 2 || n > 6 || trans != 1) continue;
                                if (pass == 0) { if (p2 && p4 && p6) continue; if (p4 && p6 && p8) continue; }
                                else { if (p2 && p4 && p8) continue; if (p2 && p6 && p8) continue; }
                                remove.Add(new Point(x, y));
                            }
                    if (remove.Count > 0) changed = true;
                    foreach (Point p in remove) a[p.Y, p.X] = false;
                }
            } while (changed);
            return a;
        }
        private static double[,] DistanceMap(bool[,] sk)
        {
            int h = sk.GetLength(0), w = sk.GetLength(1);
            byte[,] src = new byte[h, w];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) src[y, x] = sk[y, x] ? (byte)0 : (byte)255;
            using (Mat mat = WriteGray(src)) using (Mat dist = new Mat())
            {
                CvInvoke.DistanceTransform(mat, dist, null, DistType.L2, 3);
                using (var im = dist.ToImage<Gray, float>())
                {
                    double[,] outp = new double[h, w];
                    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) outp[y, x] = im.Data[y, x, 0];
                    return outp;
                }
            }
        }
        private static double Trim(List<double> vals)
        {
            if (vals.Count == 0) return 10.0;
            vals.Sort(); int keep = Math.Max(1, (int)(vals.Count * .82));
            double sum = 0; for (int i = 0; i < keep; i++) sum += Math.Min(vals[i], 7.0);
            return sum / keep;
        }
        private static int TopBarCut(byte[,] g)
        {
            int h = g.GetLength(0), w = g.GetLength(1); if (h < 18 || w < 18) return 0;
            double[] fraction = new double[h];
            for (int y = 0; y < h; y++) { int count = 0; for (int x = 0; x < w; x++) if (g[y, x] > 0) count++; fraction[y] = (double)count / w; }
            if (fraction.Take(Math.Min(3, h)).Max() < .72) return 0;
            int maxrow = Math.Max(2, Math.Min((int)(h * .35), h - 6)), last = -1;
            for (int y = 0; y < maxrow; y++) if (fraction[y] > .64) last = y;
            if (last < 0 || last + 1 >= maxrow - 1) return 0;
            return Math.Min(h - 8, last + 3);
        }
        public static Match BandMatch(byte[,] golden, byte[,] test, Rectangle roi,
            int xRadius = 48, int yRadius = 12, int searchPad = 12, int maxXRadius = 96, bool retry = false)
        {
            int x0 = roi.X, y0 = roi.Y, W = roi.Width, H = roi.Height;
            int gh = golden.GetLength(0), gw = golden.GetLength(1), th = test.GetLength(0), tw = test.GetLength(1);
            if (x0 < 0 || y0 < 0 || x0 + W > gw || y0 + H > gh || W <= 0 || H <= 0) return null;
            byte[,] g = Slice(golden, x0, y0, W, H);
            int bx0 = Math.Max(0, x0 - xRadius - searchPad), bx1 = Math.Min(tw, x0 + W + xRadius + searchPad);
            int by0 = Math.Max(0, y0 - yRadius - searchPad), by1 = Math.Min(th, y0 + H + yRadius + searchPad);
            if (bx1 - bx0 < W || by1 - by0 < H) return null;
            byte[,] source = Slice(test, bx0, by0, bx1 - bx0, by1 - by0);
            int bar = TopBarCut(g); bool[,] gs = Skeleton(g), ts = Skeleton(source);
            for (int y = 0; y < bar; y++) for (int x = 0; x < W; x++) gs[y, x] = false;
            var gy = new List<Point>(); for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (gs[y, x]) gy.Add(new Point(x, y));
            if (gy.Count < 8) return null;
            double[,] dg = DistanceMap(gs), dt = DistanceMap(ts);
            var cache = new Dictionary<long, double>();
            Func<int, int, double> ev = (dx, dy) => {
                long key = ((long)dx << 32) | (uint)dy; double value; if (cache.TryGetValue(key, out value)) return value;
                int sx = x0 + dx - bx0, sy = y0 + dy - by0;
                if (sx < 0 || sy < 0 || sx + W > bx1 - bx0 || sy + H > by1 - by0) return cache[key] = 99.0;
                var a = new List<double>(gy.Count); var b = new List<double>(gy.Count);
                foreach (Point p in gy) a.Add(dt[sy + p.Y, sx + p.X]);
                int testCount = 0;
                for (int y = bar; y < H; y++) for (int x = 0; x < W; x++) if (ts[sy + y, sx + x]) { testCount++; b.Add(dg[y, x]); }
                if (testCount < 8) return cache[key] = 99.0;
                double ratio = (double)testCount / gy.Count;
                double penalty = 1.6 * Math.Max(0, .58 - ratio) + .7 * Math.Max(0, ratio - 2.0);
                return cache[key] = .5 * (Trim(a) + Trim(b)) + penalty;
            };
            var options = new List<Candidate>();
            Action<int, int> evaluate = (dx, dy) => { double score = ev(dx, dy); options.Add(new Candidate { Dx = dx, Dy = dy, Score = score, Penalized = score + .001 * (Math.Abs(dx) + Math.Abs(dy)) }); };
            for (int dy = -yRadius; dy <= yRadius; dy += 3) for (int dx = -xRadius; dx <= xRadius; dx += 3) evaluate(dx, dy);
            // Python includes zero separately, including when radius isn't divisible by 3.
            var xs = Enumerable.Range(0, xRadius * 2 / 3 + 2).Select(i => -xRadius + 3 * i).Where(i => i <= xRadius).ToList();
            var ys = Enumerable.Range(0, yRadius * 2 / 3 + 2).Select(i => -yRadius + 3 * i).Where(i => i <= yRadius).ToList();
            if (!xs.Contains(0)) foreach (int dy in ys) evaluate(0, dy);
            if (!ys.Contains(0)) foreach (int dx in xs) evaluate(dx, 0);
            if (!xs.Contains(0) && !ys.Contains(0)) evaluate(0, 0);
            Func<IEnumerable<Candidate>, List<Candidate>> sorted = a => a.OrderBy(q => q.Penalized).ThenBy(q => q.Score).ThenBy(q => q.Dx).ThenBy(q => q.Dy).ToList();
            var centers = new List<Candidate>();
            foreach (Candidate c in sorted(options))
            {
                if (centers.All(other => Math.Abs(c.Dx - other.Dx) > 5 || Math.Abs(c.Dy - other.Dy) > 4)) centers.Add(c);
                if (centers.Count >= 4) break;
            }
            foreach (Candidate c in centers)
                for (int dy = Math.Max(-yRadius, c.Dy - 3); dy <= Math.Min(yRadius, c.Dy + 3); dy++)
                    for (int dx = Math.Max(-xRadius, c.Dx - 3); dx <= Math.Min(xRadius, c.Dx + 3); dx++) evaluate(dx, dy);
            Candidate best = sorted(options)[0]; double before = ev(0, 0);
            bool xBoundary = Math.Abs(best.Dx) >= xRadius - 1;
            if (xBoundary && !retry && maxXRadius > xRadius)
                return BandMatch(golden, test, roi, Math.Min(maxXRadius, Math.Max(xRadius + 20, xRadius * 2)), yRadius, searchPad, maxXRadius, true);
            bool boundary = xBoundary || Math.Abs(best.Dy) >= yRadius - 1;
            bool accepted = best.Score < 2.7 && !boundary && (before - best.Score >= .15 || (best.Dx == 0 && best.Dy == 0));
            int udx = accepted ? best.Dx : 0, udy = accepted ? best.Dy : 0;
            return new Match
            {
                BestDx = best.Dx,
                BestDy = best.Dy,
                UsedDx = udx,
                UsedDy = udy,
                Score = best.Score,
                Before = before,
                Accepted = accepted,
                SearchRadiusUsed = xRadius,
                Reason = boundary ? "boundary" : !accepted ? "weak_or_poor_match" : "accepted",
                GoldenRoi = roi,
                Golden = g,
                Original = Slice(test, x0, y0, W, H),
                Best = Slice(test, x0 + best.Dx, y0 + best.Dy, W, H),
                Used = Slice(test, x0 + udx, y0 + udy, W, H)
            };
        }
    }
}

// ===== NativeCharacterAlignmentPipeline.cs =====
// C#-only translation of Python top-level alignment sequence; does not execute Python.
// API accepts already-cropped Yin/Yang areas from the existing C# camera pipeline.
namespace StandardOPage
{
    public static class NativeCharacterAlignmentPipeline
    {
        public sealed class CharacterResult
        {
            public int FontPt, CharacterIndex;
            public CharacterBandMatcher.Match Alignment;
        }
        public sealed class GroupResult
        {
            public string Side, Group;
            public int StripStartX;
            public double EccRotation;
            public byte[,] Golden, Aligned;
            public List<CharacterResult> Characters = new List<CharacterResult>();
        }
        private static double Corr(double[] a, double[] b)
        {
            int n = a.Length; if (b.Length != n) return -1;
            double ma = a.Average(), mb = b.Average(), aa = 0, bb = 0, ab = 0;
            for (int i = 0; i < n; i++) { double x = a[i] - ma, y = b[i] - mb; aa += x * x; bb += y * y; ab += x * y; }
            return aa > 1e-9 && bb > 1e-9 ? ab / Math.Sqrt(aa * bb) : -1;
        }
        private static (byte[,] strip, int startX) Coarse(byte[,] area, byte[,] reference)
        {
            int ah = area.GetLength(0), aw = area.GetLength(1), rh = reference.GetLength(0), rw = reference.GetLength(1);
            if (ah < rh || aw < rw) throw new ArgumentException("Measured image smaller than reference");
            using (Mat a = CharacterBandMatcher.WriteGray(area)) using (Mat b = CharacterBandMatcher.WriteGray(reference))
            using (Mat a2 = new Mat()) using (Mat b2 = new Mat()) using (Mat match = new Mat())
            {
                int sw = (int)Math.Round(aw * .5, MidpointRounding.ToEven), sh = (int)Math.Round(ah * .5, MidpointRounding.ToEven);
                int tw = (int)Math.Round(rw * .5, MidpointRounding.ToEven), th = (int)Math.Round(rh * .5, MidpointRounding.ToEven);
                CvInvoke.Resize(a, a2, new Size(sw, sh), 0, 0, Inter.Nearest);
                CvInvoke.Resize(b, b2, new Size(tw, th), 0, 0, Inter.Nearest);
                CvInvoke.MatchTemplate(a2, b2, match, TemplateMatchingType.CcorrNormed);
                double min = 0, max = 0; Point minLoc = new Point(), maxLoc = new Point();
                CvInvoke.MinMaxLoc(match, ref min, ref max, ref minLoc, ref maxLoc);
                int x = Math.Max(0, Math.Min(aw - rw, maxLoc.X * 2));
                // Original Python projection uses 1 row in every 4 rows, and full-resolution X.
                double[] A = new double[aw], B = new double[rw];
                for (int y = 0; y < ah; y += 4) for (int k = 0; k < aw; k++) if (area[y, k] > 0) A[k]++;
                for (int y = 0; y < rh; y += 4) for (int k = 0; k < rw; k++) if (reference[y, k] > 0) B[k]++;
                double best = -1; int bestX = -1;
                for (int start = Math.Max(0, x - 20); start <= Math.Min(aw - rw, x + 20); start++)
                {
                    double[] section = new double[rw]; Array.Copy(A, start, section, 0, rw);
                    double corr = Corr(section, B);
                    if (corr > best) { best = corr; bestX = start; }
                }
                if (bestX >= 0 && best > .5) x = bestX;
                return (CharacterBandMatcher.Slice(area, x, 0, rw, ah), x);
            }
        }
        private static double[,] RotateSeed(int w, int h, double angle, double dx, double dy)
        {
            double theta = angle * Math.PI / 180.0, c = Math.Cos(theta), s = Math.Sin(theta);
            // OpenCV getRotationMatrix2D(center=(w/2,h/2), angle, scale=1).
            return new double[,] { { c, s, (1 - c) * w / 2.0 - s * h / 2.0 + dx }, { -s, c, s * w / 2.0 + (1 - c) * h / 2.0 + dy } };
        }
        private static Matrix<float> FloatMatrix(double[,] m)
        {
            var mat = new Matrix<float>(2, 3);
            for (int i = 0; i < 2; i++) for (int j = 0; j < 3; j++) mat[i, j] = (float)m[i, j];
            return mat;
        }
        private static double[,] Invert(double[,] m)
        {
            double det = m[0, 0] * m[1, 1] - m[0, 1] * m[1, 0];
            double a = m[1, 1] / det, b = -m[0, 1] / det, c = -m[1, 0] / det, d = m[0, 0] / det;
            return new double[,] { { a, b, -a * m[0, 2] - b * m[1, 2] }, { c, d, -c * m[0, 2] - d * m[1, 2] } };
        }
        private static byte[,] Warp(byte[,] src, double[,] map, int w, int h, Inter interpolation)
        {
            using (Mat a = CharacterBandMatcher.WriteGray(src)) using (Mat result = new Mat()) using (var M = FloatMatrix(map))
            {
                CvInvoke.WarpAffine(a, result, M, new Size(w, h), interpolation, Emgu.CV.CvEnum.Warp.Default, BorderType.Constant, new MCvScalar(0));
                return CharacterBandMatcher.ReadGray(result);
            }
        }
        private static double Chamfer(byte[,] a, byte[,] b)
        {
            // Edge-image bidirectional Chamfer on the small ECC assessment image.
            using (Mat aa = CharacterBandMatcher.WriteGray(a)) using (Mat bb = CharacterBandMatcher.WriteGray(b))
            using (Mat ga = new Mat()) using (Mat gb = new Mat()) using (Mat ea = new Mat()) using (Mat eb = new Mat())
            {
                CvInvoke.GaussianBlur(aa, ga, new Size(3, 3), 0);
                CvInvoke.GaussianBlur(bb, gb, new Size(3, 3), 0);
                CvInvoke.Canny(ga, ea, 60, 150); CvInvoke.Canny(gb, eb, 60, 150);
                byte[,] x = CharacterBandMatcher.ReadGray(ea), y = CharacterBandMatcher.ReadGray(eb);
                int h = x.GetLength(0), w = x.GetLength(1);
                if (h > 40 && w > 20) { for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) if (j < 18 || j >= h - 18 || i < 8 || i >= w - 8) { x[j, i] = 0; y[j, i] = 0; } }
                int nx = 0, ny = 0;
                byte[,] px = new byte[h, w], py = new byte[h, w];
                for (int j = 0; j < h; j++) for (int i = 0; i < w; i++)
                    {
                        if (x[j, i] != 0) { nx++; px[j, i] = 0; } else px[j, i] = 255;
                        if (y[j, i] != 0) { ny++; py[j, i] = 0; } else py[j, i] = 255;
                    }
                if (nx < 30 || ny < 30) return 999;
                using (Mat ax = CharacterBandMatcher.WriteGray(px)) using (Mat ay = CharacterBandMatcher.WriteGray(py))
                using (Mat dx = new Mat()) using (Mat dy = new Mat())
                {
                    CvInvoke.DistanceTransform(ax, dx, null, DistType.L2, 3);
                    CvInvoke.DistanceTransform(ay, dy, null, DistType.L2, 3);
                    using (var dxa = dx.ToImage<Gray, float>()) using (var dya = dy.ToImage<Gray, float>())
                    {
                        double sx = 0, sy = 0;
                        for (int j = 0; j < h; j++) for (int i = 0; i < w; i++)
                            {
                                if (x[j, i] > 0) sx += Math.Min(dya.Data[j, i, 0], 8);
                                if (y[j, i] > 0) sy += Math.Min(dxa.Data[j, i, 0], 8);
                            }
                        return .5 * (sx / nx + sy / ny);
                    }
                }
            }
        }
        private static (byte[,] aligned, double angle) EccRigid(byte[,] golden, byte[,] test, double scale = .33)
        {
            int h = golden.GetLength(0), w = golden.GetLength(1);
            int sw = Math.Max(32, (int)Math.Round(w * scale, MidpointRounding.ToEven));
            int sh = Math.Max(32, (int)Math.Round(h * scale, MidpointRounding.ToEven));
            using (Mat gg = CharacterBandMatcher.WriteGray(golden)) using (Mat tt = CharacterBandMatcher.WriteGray(test))
            using (Mat g0 = new Mat()) using (Mat t0 = new Mat()) using (Mat ga = new Mat()) using (Mat ta = new Mat())
            using (Mat gf = new Mat()) using (Mat tf = new Mat())
            {
                CvInvoke.Resize(gg, g0, new Size(sw, sh)); CvInvoke.Resize(tt, t0, new Size(sw, sh));
                CvInvoke.GaussianBlur(g0, ga, new Size(3, 3), 0); CvInvoke.GaussianBlur(t0, ta, new Size(3, 3), 0);
                ga.ConvertTo(gf, DepthType.Cv32F, 1.0 / 255.0); ta.ConvertTo(tf, DepthType.Cv32F, 1.0 / 255.0);
                double response; var phase = CvInvoke.PhaseCorrelate(gf, tf, null, out response);
                double best = double.MaxValue; double[,] bestForward = null;
                foreach (double angle in new double[] { -1, 0, 1 })
                {
                    try
                    {
                        using (var init = FloatMatrix(RotateSeed(sw, sh, angle, -phase.X, -phase.Y)))
                        {
                            // Python: ECC(template=test, input=golden, seed=test->golden)
                            // OpenCV returns map for WARP_INVERSE_MAP; invert to compare as in Python.
                            CvInvoke.FindTransformECC(tf, gf, init, MotionType.Euclidean, new MCvTermCriteria(65, 1e-5));
                            double[,] inv = new double[2, 3]; for (int i = 0; i < 2; i++) for (int j = 0; j < 3; j++) inv[i, j] = init[i, j];
                            double[,] forward = Invert(inv);
                            byte[,] wimg = Warp(CharacterBandMatcher.ReadGray(ga), forward, sw, sh, Inter.Linear);
                            double score = Chamfer(wimg, CharacterBandMatcher.ReadGray(ta));
                            if (score < best) { best = score; bestForward = forward; }
                        }
                    }
                    catch (Exception) { continue; }
                }
                if (bestForward == null) throw new InvalidOperationException("ECC did not converge");
                // S_inv * M * S (allows slight actual x/y scaling differences).
                double sx = (double)sw / w, sy = (double)sh / h;
                double[,] M ={{bestForward[0,0],bestForward[0,1]*sy/sx,bestForward[0,2]/sx},
                             {bestForward[1,0]*sx/sy,bestForward[1,1],bestForward[1,2]/sy}};
                double rotation = Math.Atan2(M[0, 1], M[0, 0]) * 180 / Math.PI;
                // Python: inverse map is used for final test-to-Golden warp.
                byte[,] aligned = Warp(test, Invert(M), w, h, Inter.Nearest);
                return (aligned, rotation);
            }
        }
        public static List<GroupResult> Analyze(Mat alreadyCroppedArea, string goldenDirectory, string side,
            int xRadius = 48, int yRadius = 12, int maxXRadius = 96, double eccScale = .33)
        {
            if (side != "Yin" && side != "Yang") throw new ArgumentException("side must be Yin or Yang");
            var loaded = GoldenCharacters.Load(goldenDirectory, side);
            byte[,] refbin = GoldenCharacters.Binary(loaded.reference, side == "Yin");
            using (Mat srcGray = new Mat())
            {
                if (alreadyCroppedArea.NumberOfChannels == 1) alreadyCroppedArea.CopyTo(srcGray);
                else CvInvoke.CvtColor(alreadyCroppedArea, srcGray, ColorConversion.Bgr2Gray);
                byte[,] imagebin = GoldenCharacters.Binary(CharacterBandMatcher.ReadGray(srcGray), side == "Yin");
                var coarse = Coarse(imagebin, refbin);
                var results = new List<GroupResult>();
                foreach (string group in new[] { "A", "B" })
                {
                    int first = group == "A" ? 3 : 9, last = group == "A" ? 8 : 12;
                    int left = loaded.xoffsets[first];
                    int right = last == 12 ? refbin.GetLength(1) : loaded.xoffsets[last + 1];
                    int len = right - left, height = refbin.GetLength(0);
                    byte[,] g = CharacterBandMatcher.Slice(refbin, left, 0, len, height);
                    byte[,] t = CharacterBandMatcher.Slice(coarse.strip, left, 0, len, coarse.strip.GetLength(0));
                    var ecc = EccRigid(g, t, eccScale);
                    var result = new GroupResult
                    {
                        Side = side,
                        Group = group,
                        Golden = g,
                        Aligned = new byte[height, len],
                        EccRotation = ecc.angle,
                        StripStartX = coarse.startX
                    };
                    foreach (var glyph in loaded.glyphs.Where(r => r.FontPt >= first && r.FontPt <= last)
                        .OrderBy(r => r.FontPt).ThenBy(r => r.Index))
                    {
                        int offset = loaded.xoffsets[glyph.FontPt] - left;
                        var roi = new Rectangle(offset + glyph.X0, glyph.Y0, glyph.X1 - glyph.X0, glyph.Y1 - glyph.Y0);
                        var match = CharacterBandMatcher.BandMatch(g, ecc.aligned, roi, xRadius, yRadius, 12, maxXRadius);
                        if (match == null) continue;
                        result.Characters.Add(new CharacterResult { FontPt = glyph.FontPt, CharacterIndex = glyph.Index, Alignment = match });
                        for (int y = 0; y < roi.Height; y++) for (int x = 0; x < roi.Width; x++)
                                result.Aligned[roi.Y + y, roi.X + x] = match.Used[y, x];
                    }
                    results.Add(result);
                }
                return results;
            }
        }
    }
}
